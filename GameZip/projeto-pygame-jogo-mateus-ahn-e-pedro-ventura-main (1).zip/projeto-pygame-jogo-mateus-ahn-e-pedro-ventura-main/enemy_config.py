# Enemy configuration for easy editing

# Base screen reference
BASE_WIDTH = 1920
BASE_HEIGHT = 1080

# Enemy speed settings
ENEMY_BASE_SPEED_MIN = 3
ENEMY_BASE_SPEED_MAX = 5
ENEMY_LEVEL_SPEED_SCALE = 0.4  # Speed increase per level


# Enemy quantity per level (edit as needed)
LEVEL_ENEMY_COUNTS = {
    1: 10,
    2: 15,
    3: 15,
    4: 20,
    5: 20,
    6: 25,
    7: 30,
    8: 30,
    9: 35,
    10: 40

# Get through levels faster for boss testing
    # 1: 0,
    # 2: 0,
    # 3: 0,
    # 4: 0,
    # 5: 0,
    # 6: 0,
    # 7: 0,
    # 8: 0,
    # 9: 0,
    # 10: 0


}

# Player lives
PLAYER_LIVES = 5

# Enemy damage (edit as needed)
ENEMY_DAMAGE = {
    'lower': 1,
    'upper': 2,
    'word': 3,
    'boss': 5
}

# Enemy words (edit as needed)
ENEMY_WORDS = [
    "attack", "robot", "circuit", "keyboard", "dog", "cat", "tower", "defend",
    "dragon", "castle", "enemy", "shield", "machine", "gear", "hostile",
    "network", "system", "protocol", "metal"
]

# --- Translation dictionaries ---
ENEMY_WORDS_PT = {
    "attack": "ataque",
    "robot": "robo",
    "circuit": "circuito",
    "keyboard": "chave",
    "dog": "cao",
    "cat": "gato",
    "tower": "torre",
    "defend": "defender",
    "dragon": "dragao",
    "castle": "castelo",
    "enemy": "inimigo",
    "shield": "escudo",
    "machine": "maquina",
    "gear": "rosca",
    "hostile": "hostil",
    "network": "rede",
    "system": "sistema",
    "protocol": "protocolo",
    "metal": "metal"
}

# Complete game translations
TRANSLATIONS = {
    "en": {
        "game_title": "TOWER OF TYPING",
        "start": "[S] Start",
        "quit": "[Q] Quit", 
        "language": "Language",
        "english": "English",
        "portuguese": "Português",
        "highscore": "Highscore",
        "instructions_title": "INSTRUCTIONS",
        "instructions_1": "Different kinds of enemies approach.",
        "instructions_2": "Type their characters to kill them",
        "instructions_continue": "Press any key to continue",
        "level": "Level",
        "score": "Score",
        "paused": "PAUSED",
        "resume": "[ESC] Resume",
        "menu": "[M] Menu",
        "you_died": "YOU DIED",
        "new_highscore": "New Highscore! Type your name and Enter:",
        "press_key_highscores": "Press any key to see Highscores",
        "top_10_highscores": "TOP 10 HIGHSCORES",
        "restart": "[R] Restart",
        "level_complete": "Level {} Complete!",
        "congratulations": "CONGRATULATIONS!",
        "congratulations_message": "                  Thank you for playing our game. \n We hope you had as much fun playing as we did creating it.",
        "congratulations_hint": "Press Enter to save",
        "final_message": "Thank you for playing our game. It was a very fun experience and we hope that we were able to share this joy with you. Press esc and play again",
        "level_messages": {
            1: "Type lOWERCASE letters to destroy enemies!",
            2: "Lookout the Enemies got faster!",
            3: "Beware the UPPERCASE enemies!",
            4: "They got even faster!",
            5: "Be careful they have WORDS now!",
            6: "The enemy's engine is running faster!",
            7: "Their numbers are increasing!",
            8: "Watch out they got even more reinforcements!",
            9: "Danger! Danger! BOSS incoming!",
            10: "Its over!"
        },
        "boss_texts": {
            0: ("Artificial intelligence brings many\n"
                "benefits but also serious ethical\n"
                "concerns. It often relies on personal\n"
                "data which can be misused without\n"
                "proper safeguards."),
            1: ("AI can also show bias because it\n"
                "learns from human data. These biases\n"
                "can cause unfair results in jobs\n"
                "healthcare and law."),
            2: ("Automation from AI raises questions\n"
                "about jobs and fairness. As machines\n"
                "replace workers many people may lose\n"
                "income.")
        }
    },
    "pt": {
        "game_title": "DIGITORRE",
        "start": "[S] Iniciar",
        "quit": "[Q] Sair",
        "language": "Idioma",
        "english": "English",
        "portuguese": "Português", 
        "highscore": "Recorde",
        "instructions_title": "INSTRUÇÕES",
        "instructions_1": "Defenda a torre de inimigos.",
        "instructions_2": "Digite seus caracteres para matá-los",
        "instructions_continue": "Pressione qualquer tecla para continuar",
        "level": "Nível",
        "score": "Pontuação",
        "paused": "PAUSADO",
        "resume": "[ESC] Continuar",
        "menu": "[M] Menu",
        "you_died": "VOCÊ MORREU",
        "new_highscore": "Novo Recorde! Digite seu nome e pressione Enter:",
        "press_key_highscores": "Pressione qualquer tecla",
        "top_10_highscores": "TOP 10 RECORDES",
        "restart": "[R] Reiniciar",
        "level_complete": "Nível {} Completo!",
        "congratulations": "PARABÉNS!",
        "congratulations_message": "Obrigado por jogar nosso jogo. Esperamos que você tenha se divertido jogando tanto quanto nós nos divertimos criando.",
    "congratulations_hint": "Pressione Enter para salvar",
        "final_message": "Obrigado por jogar nosso jogo. Foi uma experiência muito divertida e esperamos ter conseguido compartilhar esta alegria com você. Pressione esc e jogue novamente",
        "level_messages": {
            1: "Digite letras MINÚSCULAS para destruir inimigos!",
            2: "Cuidado, os inimigos ficaram mais rápidos!",
            3: "Cuidado com os inimigos MAIÚSCULOS!",
            4: "Eles ficaram ainda mais rápidos!",
            5: "Cuidado, agora eles têm PALAVRAS!",
            6: "O motor dos inimigos está funcionando mais rápido!",
            7: "Seus números estão aumentando!",
            8: "Cuidado, eles receberam ainda mais reforços!",
            9: "Perigo! Perigo! CHEFE chegando!",
            10: "Acabou!"
        },
        "boss_texts": {
            0: ("A inteligencia artificial traz muitos\n"
                "beneficios mas tambem preocupacoes\n"
                "eticas serias. Ela depende de dados\n"
                "pessoais que podem ser mal utilizados\n"
                "sem protecoes adequadas."),
            1: ("A IA tambem pode mostrar preconceito\n"
                "porque aprende de dados humanos. Esses\n"
                "preconceitos podem causar resultados\n"
                "injustos em empregos saude e direito."),
            2: ("A automacao da IA levanta questoes\n"
                "sobre empregos e justica. Conforme\n"
                "maquinas substituem trabalhadores muitas\n"
                "pessoas podem perder renda.")
        }
    }
}

# Translation helper function
def get_text(key, language="en", *args):
    """Get translated text for given key and language"""
    try:
        text = TRANSLATIONS[language][key]
        if args:
            return text.format(*args)
        return text
    except (KeyError, IndexError):
        # Fallback to English if translation not found
        try:
            text = TRANSLATIONS["en"][key]
            if args:
                return text.format(*args)
            return text
        except (KeyError, IndexError):
            return key  # Return the key itself as last resort
