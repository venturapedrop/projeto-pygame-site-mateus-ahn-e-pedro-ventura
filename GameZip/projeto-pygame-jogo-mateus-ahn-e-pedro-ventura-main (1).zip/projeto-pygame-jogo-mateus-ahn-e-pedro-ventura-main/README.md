
# Descrição do jogo

**Tower of Typing** é um jogo de "tower defense" baseado em digitação, onde o jogador deve defender sua torre digitando as palavras que aparecem nos inimigos que se aproximam. O jogo apresenta múltiplos níveis com dificuldade crescente, animações, efeitos sonoros e um sistema de pontuação e ranking.

# Características principais:
- **10 níveis progressivos** com tipos de inimigos diferentes (letras minúsculas, maiúsculas, palavras completas)
- **Sistema de chefes** nos níveis 9 e 10 com textos complexos
- **Suporte PT/EN** (Português e Inglês) com tradução adaptada
- **Backgrounds dinâmicos** que mudam conforme o progresso do nível
- **Animações de sprites** para todos os personagens e explosões
- **Sistema de vidas** com dano progressivo baseado no tipo de inimigo
- **Efeitos sonoros** incluindo música de fundo e explosões
- **Sistema de pontuação e ranking** guardado em arquivo JSON
- **Tela de vitoria** com sistema de pontos bônus ocultos
- **Polimento visual contínuo** com sprites dimensionados para clareza e caixas de texto alinhadas aos personagens

# Funcionalidades técnicas:
- **Orientação a objetos** com classes e responsabilidades separadas
- **Herança de pygame.Sprite** para detecção de colisão
- **Arquitetura baseada em telas** com classes separadas para cada estado do jogo
- **Documentação completa** com docstrings em todas as classes e métodos
- **Código organizado** em múltiplos arquivos para melhor manutenibilidade

# Integrantes do grupo

- **Mateus Ahn**
- **Pedro Ventura**

# Como executar

# Pré-requisitos:
- Python 3.7 ou superior
- Pygame library

# Instalação:
1. Clone ou baixe este repositório
2. Instale a biblioteca Pygame:
   ```bash
   pip install pygame
   ```

# Execução:
```bash
python3 game.py
```

# Controles:
- **Menu principal:**
  - `S` - Iniciar jogo
  - `Q` - Sair
  - `L` - Alternar idioma (Português/English)
  
- **Durante o jogo:**
  - Digite as letras/palavras que aparecem nos inimigos
  - `ESC` - Pausar jogo
  
- **Menu de pausa:**
  - `ESC` - Retomar jogo
  - `M` - Voltar ao menu principal

- **Telas de pontuação:**
  - `R` - Reiniciar jogo
  - `M` - Menu principal
  - `Enter` - Confirmar entrada de nome

# Estrutura do projeto

```
projeto-pygame-jogo/
├── game.py                 # Módulo principal com lógica do jogo
├── game_objects.py         # Classes de objetos do jogo (sprites)
├── screens.py              # Classes das telas/estados do jogo
├── enemy_config.py         # Configurações de inimigos e traduções
├── highscore.json          # Arquivo de pontuações salvas
├── README.md              # Este arquivo
├── Assets/                # Recursos gráficos e sonoros
│   ├── Player/           # Sprites do jogador
│   ├── Drones/           # Sprites dos inimigos
│   ├── Boss/             # Sprites dos chefes
│   ├── Explosion/        # Frames de animação de explosão
│   ├── TextBoxes/        # Caixas de texto para inimigos
│   ├── Sounds/           # Efeitos sonoros e música
│   └── Font/             # Fontes personalizadas
└── Backgrounds/          # Imagens de fundo por nível
```

# Arquitetura técnica

# Classes principais:

# game.py
- **Game**: Classe principal que gerencia estados, eventos e renderização
- **LevelManager**: Gerencia progressão de níveis e spawn de inimigos
- **UIManager**: Utilitários estáticos para renderização de interface

# game_objects.py
- **Explosion**: Sprite de animação de explosão (herda de pygame.sprite.Sprite)
- **Defender**: Sprite da torre do jogador com animações
- **Enemy**: Sprite dos inimigos com sistema de texto e animação

# screens.py
- **BaseScreen**: Classe base para todas as telas
- **MenuScreen**: Tela do menu principal
- **InstructionsScreen**: Tela de instruções
- **GameScreen**: Tela principal de jogo
- **PauseScreen**: Tela de pausa
- **LoseScreen**: Tela de game over
- **HighscoresScreen**: Tela de rankings
- **CongratulationsScreen**: Tela de agradecimento com bônus
- **WinScreen**: Tela de entrada de nome para ranking

# Características de programação:

1. **Orientação a objetos**: Todas as entidades são classes bem estruturadas
2. **Herança pygame.Sprite**: Collision detection eficiente usando sprite groups
3. **Documentação completa**: Docstrings em todos os métodos e classes
4. **Separação de responsabilidades**: Arquivos organizados por funcionalidade
5. **Tratamento de eventos**: Sistema robusto de estados e transições
6. **Persistência de dados**: Sistema de highscores em JSON
7. **Escalabilidade**: Fácil adição de novos níveis e funcionalidades

## Atualizações recentes

- Redimensionamento do jogador e dos chefes para garantir leitura confortável das palavras.
- Alinhamento das caixas de texto dos chefes com os sprites, mantendo o texto ligeiramente menor para reforçar contraste.
- Ajuste do posicionamento das caixas de texto dos inimigos para evitar sobreposição com o placar de highscores.

# Link para vídeo demonstração

https://youtu.be/EvHpDc8HGJ8
